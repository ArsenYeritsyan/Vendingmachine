package com.company;

import java.io.IOException;

public class VendingExceptions extends Exception {
    public VendingExceptions() {
        super();
    }
}



