package com.company;

import java.io.IOException;

public class VendingExceptions extends RuntimeException {

    public VendingExceptions() {
        super();
    }
}



